import UIKit

func A(_ accion: String, _ universidad: String, _ intentos: Int) -> String {
   
    func B(_ uni: String) -> String {
        if uni == "tecsup" {
            return "TECSUP: Instituto tecnológico especializado en carreras técnicas."
        } else {
            return C(uni)
        }
    }
   
    func C(_ uni: String) -> String {
        if uni == "uni" {
            return "UNI: Universidad Nacional de Ingeniería."
        } else {
            return D(uni)
        }
    }
   
    func D(_ uni: String) -> String {
        if uni == "unalm" {
            return "UNALM: Universidad Agraria."
        } else {
            return E(uni)
        }
    }
   
    func E(_ uni: String) -> String {
        if uni == "upn" {
            return "UPN: Universidad Privada del Norte."
        } else {
            return "Universidad no encontrada."
        }
    }
   
    if accion != "buscar" {
        return "Acción inválida."
    }
   
    if intentos > 2 {
        return "Máximo 2 intentos permitidos."
    }
   
    return B(universidad.lowercased())
}

print(A("buscar", "tecsup",2))
