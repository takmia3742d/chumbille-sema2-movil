import UIKit

var montoin: Double = 50000
var tasa: Double = 0.08


let interest = montoin * tasa
print("El interés es: \(interest)")
 
if interest > 7000 {
    montoin += interest
    print("los interese no superan los 7000. No se reinvierte")
}
    else {
        print("los interese superan los 7000. Se reinvierte")
    }
    print(  "Capital final en la cuenta : \(montoin)")

    

    

