import UIKit

let preciouni: Double = 50.0
let cantidad: Double = 4
let descuento: Double = 10.0

let subtotal = preciouni * Double(cantidad)
let montodescuento = subtotal * (descuento / 100)
let pagototal = subtotal - montodescuento

print("Subtotal: $\(subtotal)")
print("descuento (\(descuento)%): $\(montodescuento)  ")

print("pago total : $\(pagototal)")
