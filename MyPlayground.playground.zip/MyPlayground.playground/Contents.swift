import UIKit


let actividad: String = "reposo"  
let tiempo: Int = 180
if actividad != "dormir" && actividad != "reposo" {
    print("❌ Error: Actividad inválida. Solo se permite 'dormir' o 'reposo'.")
} else if tiempo <= 0 {
    print("❌ Error: El tiempo debe ser un número entero positivo.")
} else {
    let caloriasPorMinuto: Double
    if actividad == "dormir" {
        caloriasPorMinuto = 1.08
    } else {
        caloriasPorMinuto = 1.66
    }
    let totalCalorias = caloriasPorMinuto * Double(tiempo)
    print("✅ Actividad: \(actividad.uppercased())")
    print("⏳ Tiempo: \(tiempo) minutos")
    print("🔥 Calorías consumidas: \(totalCalorias)")
}



